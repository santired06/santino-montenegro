import React from 'react';
import ReactDOM from 'react-dom';
import HolaMundo from './HolaMundo';
import Presentacion from './Presentacion';
import Contador from './Contador';
import Lista from './Lista';
import Formulario from './Formulario';
import FotoPerfil from './FotoPerfil.png';

const App = () => {
  return (
    <div>
      <HolaMundo />
      <Presentacion 
        nombre='Santino'
        apellido='Montengro'
        profesion='Desarrollador'
        imagen={FotoPerfil}
      />
      <Contador />
      <Lista />
      <Formulario />
    </div>
  );
};

ReactDOM.render(<App />, document.getElementById('root'));
