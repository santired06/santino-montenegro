import React, { useState } from 'react';

const Lista = () => {
  const [Tarea, setTarea] = useState([]);
  const [nuevaTarea, setnuevaTarea] = useState('');

  const handleAddTarea = () => {
    setTarea([...Tarea, { text: nuevaTarea, completa: false }]);
    setnuevaTarea('');
  };

  const handleToggleTarea = index => {
    setTarea(
      Tarea.map((Tarea, i) => {
        if (i === index) {
          return { ...Tarea, completa: !Tarea.completa };
        }
        return Tarea;
      })
    );
  };

  return (
    <div className='component'>
      <h2>Lista de Tarea</h2>
      <input
        type='text'
        value={nuevaTarea}
        onChange={e => setnuevaTarea(e.target.value)}
        placeholder='Agregar tarea'
      />
      <button onClick={handleAddTarea}>Agregar</button>
      <ul>
        {Tarea.map((Tarea, index) => (
          <li key={index}>
            <input
              type='checkbox'
              checked={Tarea.completa}
              onChange={() => handleToggleTarea(index)}
            />
            <span
              style={{
                textDecoration: Tarea.completa ? 'line-through' : 'none',
              }}
            >
              {Tarea.text}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Lista;
