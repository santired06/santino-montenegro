import React from 'react';

const HolaMundo = () => {
  return <h1>Hola, mundo!</h1>;
};

export default HolaMundo;
