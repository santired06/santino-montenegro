import React from 'react';

const Presentacion = ({ nombre, apellido, profesion, imagen }) => {
  return (
    <div className='component'>
      <h2>
        {nombre} {apellido}
      </h2>
      <p>{profesion}</p>
      <img src={imagen} alt={nombre} className='imagen'/>
    </div>
  );
};

export default Presentacion;
